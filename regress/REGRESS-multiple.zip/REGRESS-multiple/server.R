library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {

  # Expression that generates a scatterplot. The expression is
  # wrapped in a call to renderPlot to indicate that:
  #
  #  1) It is "reactive" and therefore should re-execute automatically
  #     when inputs change
  #  2) Its output type is a plot



	output$card1 <- renderPlot({
		set.seed( as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card2 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card3 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card4 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card5 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})




  output$scatterPlot <- renderPlot({

	# Sets the seed so whenever the plot is regenerated it will use the same data
	set.seed( input$user_seed )

	data_intercept <- rnorm( mean=0, sd=10, n=1)

	# For fairness, people who get bigger intercepts should get smaller slopes
	# I'm using reciprocal to hack this, so to make that work I get rid of
	# intercepts very close to zero
	if( abs(data_intercept)<1 ){ 
		if (data_intercept>=0) { data_intercept <- 1 }
		else { data_intercept <- -1 }
	}
	data_x1 <- rnorm( mean=0, sd=1/abs(data_intercept)*20, n=1)


	# Get the type of regression (from the input, or determine it randomly)
	x2type <- ifelse( input$regressiontype=="random", sample(c("categorical","continuous"),1), input$regressiontype )


	data_x2 <- rnorm( mean=0, sd=5, n=1 )
	data_x1x2 <- rnorm( mean=0, sd=2, n=1 )

	n <- 100



	# If we're doing regression with 1 continuous and 1 categorical variable...
	if (x2type=="categorical"){


		# Create the simulated data
		x1vals <- rnorm( mean=0, sd=10, n=n )
		x2vals <- rep( c(0,1), each=n/2 )
		err <- rnorm( mean=0, sd=15, n=100 )
		yvals <- data_intercept + data_x1*x1vals + data_x2*x2vals + data_x1x2*x1vals*x2vals + err


		### Show the results in a scatterplot

		yhats <- input$intercept + x1vals*input$x1 + x2vals*input$x2 + x1vals*x2vals*input$x1x2
		resid <- mean( (yhats-yvals)^2 )


		bestmodel <- lm( yvals ~ x1vals*x2vals )
		cb <- coef(bestmodel)
	
		plot(x1vals, yvals, pch=21+x2vals*4, bg=rgb(x2vals*.8,0,(1-x2vals)*.8,alpha=.5), col=rgb(x2vals,0,(1-x2vals),alpha=.8), xlab=bquote(italic(X[1])), ylab=bquote(italic(Y)), main=bquote(error==.(round(resid,2))) )

	lines( c(0,0), c(-1000000, 1000000), col="black", lty=2 )
	lines( c(-1000000,1000000), c(0,0), col="black", lty=2 )

		legend( "top", pch=c(21,24), pt.bg=c( rgb(0,0,.8,alpha=.5), rgb(.8,0,0,alpha=.5) ), col=c( rgb(0,0,1,alpha=.8), rgb(1,0,0,alpha=.8) ), legend=c("Group 1", "Group 2") )

		abline( input$intercept, input$x1, lwd=3, col="blue" )
		abline( input$intercept+input$x2, input$x1+input$x1x2, lwd=3, col="red", lty=1 )

		if (input$show_answer){ legend(-15,0, col="black", legend=bquote( italic(hat(Y)) == .(round(cb[1],2)) + .(round(cb[2],2))*x[1] + .(round(cb[3],2))*x[2] + .(round(cb[4],2))*x[1]*x[2] ), bg="white" ) }
	


	# If we're doing with 2 continuous variables...
	} else {



		# Create the simulated data
		x1vals <- rnorm( mean=0, sd=10, n=n )
		x2vals <- rnorm( mean=0, sd=10, n=n )
		err <- rnorm( mean=0, sd=15, n=100 )
		yvals <- data_intercept + data_x1*x1vals + data_x2*x2vals + data_x1x2*x1vals*x2vals + err



		### Show the results in a scatterplot

		yhats <- input$intercept + x1vals*input$x1 + x2vals*input$x2 + x1vals*x2vals*input$x1x2
		resid <- mean( (yhats-yvals)^2 )

		low <- which( x2vals < quantile(x2vals,.33) )
		med <- which( (x2vals>=quantile(x2vals,.33)) & (x2vals<=quantile(x2vals,.66)) )
		high <- which( x2vals > quantile(x2vals, .66) )

		bestmodel <- lm( yvals ~ x1vals*x2vals )
		cb <- coef(bestmodel)
	

		plot(
			x1vals[low],
			yvals[low],
			pch=21,
			bg=rgb(0,0,.8,alpha=.5),
			col=rgb(0,0,1,alpha=.8),
			xlab=bquote(italic(X[1])),
			ylab=bquote(italic(Y)),
			main=bquote(error==.(round(resid,2)))
		)
		points(
			x1vals[high],
			yvals[high],
			pch=24,
			bg=rgb(.8,0,0,alpha=.5),
			col=rgb(1,0,0,alpha=.8)
		)
		points(
			x1vals[med],
			yvals[med],
			pch=22,
			bg=rgb(.8,0,.8,alpha=.5),
			col=rgb(1,0,1,alpha=.8)
		)

	lines( c(0,0), c(-1000000, 1000000), col="black", lty=2 )
	lines( c(-1000000,1000000), c(0,0), col="black", lty=2 )

		x2lowval <- quantile(x2vals,.165)
		x2medval <- quantile(x2vals,.5)
		x2highval <- quantile(x2vals,.835)

		abline( input$intercept + input$x2*x2lowval, input$x1 + input$x1x2*x2lowval, lwd=3, col=rgb(0,0,1) )
		abline( input$intercept + input$x2*x2medval, input$x1 + input$x1x2*x2medval, lwd=3, col=rgb(1,0,1) )
		abline( input$intercept + input$x2*x2highval, input$x1 + input$x1x2*x2highval, lwd=3, col=rgb(1,0,0) )



		legend(
			"top",
			pch=c(21,22,24),
			pt.bg=c(
				rgb(0,0,.8,alpha=.5),
				rgb(.8,0,.8,alpha=.5),
				rgb(.8,0,0,alpha=.5)
			),
			col=c(
				rgb(0,0,1,alpha=.8),
				rgb(1,0,1,alpha=.8),
				rgb(1,0,0,alpha=.8)
			),
			legend=c("low on X2", "medium on X2", "high on X2")
		)



		if (input$show_answer){
			legend(
				-15,
				0,
				col="black",
				legend=bquote(
					italic(hat(Y))
					==
					.(round(cb[1],2))
					+
					.(round(cb[2],2))*x[1]
					+
					.(round(cb[3],2))*x[2]
					+
					.(round(cb[4],2))*x[1]*x[2]
				),
				bg="white",
				xpd=NA
			)
		}
	




	}



  })
})
