library(shiny)
library(mathjaxr)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

	# Application title
	titlePanel("REGRESS(): the game of the General Linear Model"),

	splitLayout(
		plotOutput("card1"),
		plotOutput("card2"),
		plotOutput("card3"),
		plotOutput("card4"),
		plotOutput("card5")
	),

	# Sidebar with a slider input for the number of bins
	sidebarLayout(
		sidebarPanel(
			HTML("<p>This is the interface for playing REGRESS (multiple regression version). You can also try the (easier) <a href=\"https://politzerahles.shinyapps.io/regress-simple/\">simple regression version</a>."),
			HTML("<p>For more details, see the <a href=\"https://politzerahles.github.io/regress/\">instruction page</a>."),
			p("The game is provided under a CC-BY-4.0 license by Stephen Politzer-Ahles; feel free to make a copy and/or modify it, just please acknowledge that you got it from here."),
			p("To get a different dataset, put a different number in the box labeled \"Seed\". (If you and your opponent want to use the same dataset, you can each use the same number.)"),
			p("To play with data representing one continuous and one categorical variable (i.e., two different groups), choose the \"1 categorical and 1 continuous\" button. For a slightly harder game with two continuous variables interacting, choose \"2 continuous\". If you want to live on the edge and let the robot decide for you, click the \"Choose randomly!\" button."),
			br(),
			numericInput("user_seed", "Seed (put any integer)", 1),
			numericInput("intercept", "$$b_0 \\textrm{(Intercept)}$$", 0),
			withMathJax( numericInput("x1", "$$b_1$$", 0 ) ),
			numericInput("x2", "$$b_2$$", 0 ),
			numericInput("x1x2", "$$b_1*b_2 \\textrm{(interaction)}$$", 0 ),
			radioButtons( 
				inputId = "regressiontype", 
				label = "Type of variables", 
				choices = list( 
					"1 categorical and 1 continuous" = "categorical", 
					"2 continuous" = "continuous", 
					"Choose randomly!" = "random" 
				) 
			),
			checkboxInput("coop", "Coopetition mode?", FALSE),
			checkboxInput("show_answer", "Show answer? (Don't click until after game end!)", FALSE),
			width=6
		),

		# Show a plot of the generated distribution
		mainPanel(
			plotOutput("scatterPlot"), width=4
		)
	)




))
