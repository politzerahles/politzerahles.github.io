library(shiny)
library(mathjaxr)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

  # Application title
  titlePanel("REGRESS(): the game of the General Linear Model"),



		splitLayout(
			plotOutput("card1"),
			plotOutput("card2"),
			plotOutput("card3"),
			plotOutput("card4"),
			plotOutput("card5")
		),


		# Sidebar with a slider input for the number of bins
		sidebarLayout(
			sidebarPanel(
				HTML("<p>This is the interface for playing REGRESS (simple bivariate version). You can also try the (harder) <a href=\"https://politzerahles.shinyapps.io/regress-multiple/\">multiple regression version</a>."),
				HTML("<p>For more details, see the <a href=\"https://politzerahles.github.io/regress/\">instruction page</a>."),
				p("The game is provided under a CC-BY-4.0 license by Stephen Politzer-Ahles; feel free to make a copy and/or modify it, just please acknowledge that you got it from here."),
				p("To get a different dataset, put a different number in the box labeled \"Seed\". (If you and your opponent want to use the same dataset, you can each use the same number.)"),
				br(),
				numericInput("user_seed", "Seed (put any integer)", 1),
				withMathJax( numericInput("intercept", "$$b_0 \\textrm{(Intercept)}$$", 0) ),
				numericInput("x1", "$$b_1 \\textrm{(slope)}$$", 0 ),
				checkboxInput("coop", "Coopetition mode?", FALSE),
				checkboxInput("show_answer", "Show answer? (Don't click until after game end!)", FALSE) ,
				width=6
			),

			# Show a plot of the generated distribution
			mainPanel(
				plotOutput("scatterPlot"),
				width=4
			)
		)



))
