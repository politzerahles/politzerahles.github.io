library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {

  # Expression that generates a scatterplot. The expression is
  # wrapped in a call to renderPlot to indicate that:
  #
  #  1) It is "reactive" and therefore should re-execute automatically
  #     when inputs change
  #  2) Its output type is a plot





	output$card1 <- renderPlot({
		set.seed( as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card2 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card3 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card4 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})
	output$card5 <- renderPlot({
		set.seed(as.numeric(strsplit( format(Sys.time(), "%OS6"), ".", fixed=T )[[1]][2]) + round(input$intercept) + round(input$x1) )
		cards <- c( "0.5", "0.25", "1", "2", "3", "4", "5", "0.5", "0.25", "1", "2", "-1", "-1", "multiply()", "multiply()", "negative()", "negative()", "negative()" )
		if(input$coop){plot( 0,0, type="n", xaxt="n", yaxt="n", ylab=NA, xlab=NA ); text(0,0,labels=sample(cards,1))}
	})




  output$scatterPlot <- renderPlot({

	# Sets the seed so whenever the plot is regenerated it will use the same data
	set.seed( input$user_seed )

	data_intercept <- rnorm( mean=0, sd=10, n=1)

	# For fairness, people who get bigger intercepts should get smaller slopes
	# I'm using reciprocal to hack this, so to make that work I get rid of
	# intercepts very close to zero
	if( abs(data_intercept)<1 ){ 
		if (data_intercept>=0) { data_intercept <- 1 }
		else { data_intercept <- -1 }
	}
	data_x1 <- rnorm( mean=0, sd=1/abs(data_intercept)*20, n=1)





	# Create the simulated data
	xvals <- rnorm( mean=0, sd=10, n=100 )
	err <- rnorm( mean=0, sd=15, n=100 )
	yvals <- data_intercept + data_x1*xvals + err


	### Show the results in a scatterplot

	orig_yhats <- 0 + xvals*0
	yhats <- input$intercept + xvals*input$x1
#	R2 <- cor( yvals, yhats )^2
	resid <- mean( (yhats-yvals)^2 )

	bestmodel <- lm( yvals ~ xvals )

	
	plot(xvals, yvals, pch=21, bg=rgb(0,0,.8,alpha=.5), col=rgb(0,0,1,alpha=.8), xlab=bquote(italic(X[1])), ylab=bquote(italic(Y)), main=bquote(error==.(round(resid,2))) )
	lines( c(0,0), c(-1000000, 1000000), col="black", lty=2 )
	lines( c(-1000000,1000000), c(0,0), col="black", lty=2 )

	bestMSE <- mean( resid(bestmodel)^2 )
	origMSE <- mean ( (orig_yhats-yvals)^2 )
	#goalMSE <- (bestMSE*.7) + (origMSE*.3)
	goalMSE <- bestMSE * 1.1

	legend("bottomright", legend=paste0( "Goal MSE: ", round( goalMSE ) ), col="black", inset=c(0,-0.25), xpd=T )
	

	abline( input$intercept, input$x1, lwd=3, col="red" )

	if (input$show_answer){
		abline(bestmodel)
		legend(0,0, col="black", legend=bquote( italic(hat(Y)) == .(round(coef(bestmodel)[1],2)) + .(round(coef(bestmodel)[2],2))*x ), bg="white" )

	}
	





  })





})
